Thanks for downloading this template!

Template Name: AppLanding
Template URL: https://templatemag.com/applanding-bootstrap-app-landing-template/
Author: TemplateMag.com
License: https://templatemag.com/license/